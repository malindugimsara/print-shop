export default function AboutPage() {
  return (
    <div className="relative z-10 pt-20 pb-16">
        about page
    </div>
    )
}