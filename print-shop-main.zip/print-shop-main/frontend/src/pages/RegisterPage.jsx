import { useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FcGoogle } from "react-icons/fc";
import { VscLoading } from "react-icons/vsc";

function RegisterPage() {
  const location = useLocation();
  const initialEmail = location.state?.email || "";
  const navigate = useNavigate();

  const [showSpinner, setShowSpinner] = useState(false); // ✅ Moved inside component

  const [formData, setFormData] = useState({
    name: "",
    email: initialEmail,
    address: "",
    phoneNumber: "",
    password: "",
    confirmPassword: "",
  });

  function handleChange(e) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  async function handleRegister() {
    if (formData.password !== formData.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    try {
      setShowSpinner(true); // ✅ Show loading

      await axios.post(import.meta.env.VITE_BACKEND_URL + "/api/user/", {
        name: formData.name,
        email: formData.email,
        address: formData.address,
        phoneNumber: formData.phoneNumber,
        password: formData.password,
      });

      toast.success("Registration successful!");
      navigate("/login");
    } catch (err) {
      console.error("Registration failed:", err);
      toast.error(err.response?.data?.message || "Registration failed");
    } finally {
      setShowSpinner(false); // ✅ Hide loading whether success or error
    }
  }

  function handleGoogleRegister() {
    console.log("Google register clicked");
  }

  return (
    <div className="w-full min-h-screen flex flex-col lg:flex-row bg-white overflow-hidden relative">
      {/* Left Section */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center items-center px-6 lg:px-16 py-10 relative">
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <div className="absolute top-16 left-10 w-64 h-64 bg-cyan-300/40 rotate-12 blur-3xl rounded-full"></div>
          <div className="absolute bottom-16 right-16 w-72 h-72 bg-pink-400/40 -rotate-12 blur-3xl rounded-full"></div>
          <div className="absolute top-1/2 right-1/3 w-52 h-52 bg-yellow-300/40 blur-3xl rounded-full"></div>
        </div>

        <div className="z-10 text-center max-w-md ">
          <div className="flex justify-center mb-6">
            <img src="logo1.png" alt="logo" className="w-30 md:w-45 md:h-55" />
          </div>

          <h1 className="text-4xl lg:text-6xl font-bold text-gray-800 mb-4">
            Join <span className="text-pink-600">PrintShop</span>
          </h1>
          <p className="hidden md:flex text-gray-600 text-base lg:text-lg mb-8">
            Create your account and start managing your print orders efficiently.
          </p>

          <div className="space-y-3 hidden md:flex">
            <div className="flex items-center justify-center space-x-3">
              <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
              <span className="text-gray-700 text-sm">Fast Order Management</span>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <div className="w-3 h-3 bg-pink-400 rounded-full animate-pulse"></div>
              <span className="text-gray-700 text-sm">Easy Print Tracking</span>
            </div>
            <div className="flex items-center justify-center space-x-3">
              <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
              <span className="text-gray-700 text-sm">Email Notifications</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Section (Form) */}
      <div className="w-full lg:w-1/2 flex justify-center items-center bg-gray-50 px-6 lg:px-10 py-5 md:py-10 relative">
        {/* ✅ Loading Overlay */}
        {showSpinner && (
          <div className="absolute inset-0 bg-[#2C3E50]/60 backdrop-blur-sm rounded-none flex items-center justify-center z-50 ">
            <div className="text-center">
              <VscLoading className="text-white text-4xl animate-spin mx-auto mb-3" />
              <p className="text-white text-sm">Creating your account...</p>
            </div>
          </div>
        )}

        <div className="w-full max-w-[400px] bg-white border border-gray-200 rounded-2xl shadow-lg p-6 relative">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-800 mb-1 text-center">
            Create Account
          </h1>
          <p className="text-gray-500 text-sm text-center mb-6">
            Sign up to get started with PrintShop
          </p>

          <div className="space-y-3 mb-4">
            {["name", "email", "address", "phoneNumber", "password", "confirmPassword"].map(
              (field, i) => (
                <input
                  key={i}
                  name={field}
                  value={formData[field]}
                  onChange={handleChange}
                  type={
                    field.toLowerCase().includes("password")
                      ? "password"
                      : field === "email"
                      ? "email"
                      : "text"
                  }
                  placeholder={
                    field === "confirmPassword"
                      ? "Confirm Password"
                      : field.charAt(0).toUpperCase() + field.slice(1)
                  }
                  className="w-full h-10 px-3 border border-gray-300 rounded-lg text-gray-700 text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500 transition-all"
                />
              )
            )}
          </div>

          <button
            onClick={handleRegister}
            disabled={showSpinner}
            className={`w-full h-10 text-white rounded-lg font-semibold transition-transform hover:scale-[1.02] hover:shadow-md ${
              showSpinner
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-gradient-to-r from-pink-500 to-cyan-500"
            }`}
          >
            {showSpinner ? "Registering..." : "Register"}
          </button>

          <div className="flex items-center my-4">
            <div className="flex-1 border-t border-gray-300"></div>
            <span className="px-3 text-gray-500 text-sm">or</span>
            <div className="flex-1 border-t border-gray-300"></div>
          </div>

          <button
            onClick={handleGoogleRegister}
            className="w-full h-11 bg-gradient-to-r from-green-400 to-[#48CAE4] border border-[#E0E0E0] hover:bg-[#F8F9FA] text-[#2C3E50] text-sm font-semibold rounded-lg transition-all duration-300 transform hover:scale-[1.02] flex items-center justify-center space-x-3"
          >
            <FcGoogle className="text-2xl" />
            <span>Sign in with Google</span>
          </button>

          <p className="text-center text-sm text-gray-600 mt-5">
            Already have an account?{" "}
            <Link
              to={"/login"}
              className="text-pink-600 font-semibold hover:underline"
            >
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default RegisterPage;
